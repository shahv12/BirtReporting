package com.reports.controller;

/**
 * PDFReportsController : intercepts different requests.
 * 
 */

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

import org.apache.log4j.Logger;
import org.eclipse.birt.report.engine.api.EngineException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.reports.constants.ReportConstants;
import com.reports.exception.ReportDesignException;
import com.reports.generator.PdfReportGenerator;

@Controller
public class PDFReportsController {
	final static Logger logger = Logger.getLogger(PDFReportsController.class);

	@Autowired
	PdfReportGenerator pdfReportsGenerator;

	public PDFReportsController() {}

	/**
	 * @method : printHello : intercepts requests containing the below path and
	 *         generates pdf reports
	 * @param request
	 * @param servletRequest
	 * @param servletResponse
	 * @return ModelAndView
	 */
	@RequestMapping("/reports/pdf/{reportType}")
	public ModelAndView generateReport(String request,
			@Context HttpServletRequest servletRequest,
			@Context HttpServletResponse servletResponse,
			@PathVariable("reportType") String reportType) {
		
		logger.debug(ReportConstants.REQUEST_RECEIVED_FOR_PDF_REPORTS);
		
		String reportName;
		try {
			//sends a pdf report for a given reportType for generation
			reportName = pdfReportsGenerator.generateReport(servletRequest,
					servletResponse, reportType);
		}
		catch (EngineException engineException) {
			logger.error(ReportConstants.REPORT_ENGINE_EXCEPTION,
					engineException);
			//error due to birt engine.
			return new ModelAndView(ReportConstants.WELCOME_PAGE, ReportConstants.MESSAGE,
					ReportConstants.REPORT_ENGINE_EXCEPTION
							+ ReportConstants.REPORT_GENERATION_FAILED);
		}
		catch (ReportDesignException reportDesignException) {
			logger.error(ReportConstants.DESIGN_FILE_EXCEPTION,
					reportDesignException);
			//error to due design file.
			return new ModelAndView(ReportConstants.WELCOME_PAGE, ReportConstants.MESSAGE,
					ReportConstants.REPORT_DESIGN + reportType
							+ ReportConstants.CANNOT_BE_READ
							+ ReportConstants.REPORT_GENERATION_FAILED);
		}
		//success call. Show the report name on the welcome page.
		return new ModelAndView(ReportConstants.WELCOME_PAGE,ReportConstants.MESSAGE,
				ReportConstants.REPORT + reportName
						+ ReportConstants.GENERATED_SUCCESSFULLY);

	}
}
