package com.reports.constants;

/**
 * ReportConstants : contains all the reporting constants.
 * 
 * @author Vaishali
 * 
 */

public class ReportConstants {
	public ReportConstants() {}

	//Report type  and  extention constants.
	public static final String REPORT_TYPE_PDF = "pdf";
	public static final String REPORT_TYPE_XLS = "xls";
	public static final String REPORT_EXTENTION_PDF = ".pdf";
	public static final String REPORT_EXTENTION_XLS = ".xls";
	public static final String REPORT_DESIGN_EXTENSION = ".rptdesign";
	
	//Report path constants.
	public static final String PDF_REPORT_OUTPUT_PATH = "/generated_reports/pdf/";
	public static final String XLS_REPORT_OUTPUT_PATH = "/generated_reports/xls/";
	public static final String REPORT_DESIGN_SAMPLE_FILE_PATH = "/report_design/";
	public static final String PDF_REPORT_GENERATION_PATH = "/reports/pdf";
	public static final String XLS_REPORT_GENERATION_PATH = "/reports/xls";

	//Report generation constants
	public static final String REPORT_GENERATION_FAILED = "Report generation has failed. Please check logs for details.";
	public static final String REPORT_ENGINE_EXCEPTION = "Report engine exception.";
	public static final String GENERATED_SUCCESSFULLY = " generated successfully. ";
	public static final String REQUEST_RECEIVED_FOR_PDF_REPORTS = "Request received for generating pdf reports. ";
	public static final String REQUEST_RECEIVED_FOR_XLS_REPORTS = "Request received for generating xls reports. ";
	public static final String REPORT_NAME_TO_BE_GENERATED = "name of the report to be generated ";
	public static final String READING_DESIGN_FILE = "Reading the design file as an input stream. ";
	public static final String SAVED_TO_DIRECTORY="has been saved to directory";
	public static final String DESIGN_FILE_EXCEPTION = "design file exception. ";
	public static final String READING_DESIGN_FILE_EXCEPTION="Unable to read desing file: ";
	
	//Report Constants
	public static final String WELCOME_PAGE = "welcomePage";
	public static final String CANNOT_BE_READ = "cannot be read.";
	public static final String REPORT = "Report ";
	public static final String REPORT_DESIGN = "Report design ";
	public static final String REPORT_ENGINE_INSTANCE="Report engine instance";
	public static final String REPORT_="report_";
	public static final String MESSAGE = "message";
	
	//Report engine constants
	public static final String REPORT_ENGINE_BEAN_SET="Report engine bean has been set.";
	public static final String REPORTING_ENGINE_STARTING="Birt report engine started...";
	public static final String REPORTING_ENGINE_STARTED="Birt report engine has been started.";
	public static final String REPORTING_ENGINE_SHUTDOWN="Birt report engine has been shutdown.";
	public static final String ERROR_STARTING_REPORT_ENGINE="Error in starting reporting engine. Reports cannot be generated.";
	
}	
