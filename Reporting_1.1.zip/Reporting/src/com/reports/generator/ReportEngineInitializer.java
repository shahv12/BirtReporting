package com.reports.generator;

/**
 * Starts the Birt Report Engine.
 */
import org.apache.log4j.Logger;

import org.eclipse.birt.core.exception.BirtException;
import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;

import com.reports.constants.ReportConstants;

public class ReportEngineInitializer {
	final static Logger logger = Logger
			.getLogger(ReportEngineInitializer.class);

	public ReportEngineInitializer() {
	}

	private IReportEngine reportEngine = null;

	public IReportEngine getReportEngine() {
		return reportEngine;
	}

	public void setReportEngine(IReportEngine reportEngine) {
		this.reportEngine = reportEngine;
	}

	/**
	 * Initializes the birt report engine. The report engine is started only
	 * once during startup of web container and is shut down when the
	 * application is shut down.
	 */
	public void initReportEngine(){
		try {
			logger.debug(ReportConstants.REPORTING_ENGINE_STARTING);
			
			EngineConfig engineConfig = new EngineConfig();
			Platform.startup(engineConfig);
			IReportEngineFactory engineFactory = (IReportEngineFactory) Platform
					.createFactoryObject(IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY);
			reportEngine = engineFactory.createReportEngine(engineConfig);
			
			logger.debug(ReportConstants.REPORTING_ENGINE_STARTED);
		} catch (BirtException birtException) {
			logger.fatal(ReportConstants.ERROR_STARTING_REPORT_ENGINE);
		}
	}

	public void shutDownReportEngine() {
		reportEngine.shutdown();
		logger.debug(ReportConstants.REPORTING_ENGINE_SHUTDOWN);
	}
}
