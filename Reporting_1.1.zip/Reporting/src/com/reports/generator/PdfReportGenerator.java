/**
 * PdfReportGenerator : generates pdf reports
 */
package com.reports.generator;

import java.io.InputStream;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;
import org.eclipse.birt.report.engine.api.PDFRenderOption;

import com.reports.constants.*;
import com.reports.exception.ReportDesignException;

public class PdfReportGenerator {
	final static Logger logger = Logger.getLogger(PdfReportGenerator.class);

	public PdfReportGenerator() {
	}

	public ReportEngineInitializer reportEngineBean;
	private IReportRunnable runnable = null;
	private IReportEngine reportEngine = null;
	private ServletContext servletContext = null;
	private InputStream inputStream = null;

	public ReportEngineInitializer getReportEngineBean() {
		return reportEngineBean;
	}

	public void setReportEngineBean(ReportEngineInitializer reportEngineBean) {
		this.reportEngineBean = reportEngineBean;
		logger.debug(ReportConstants.REPORT_ENGINE_BEAN_SET
				+ this.reportEngineBean);
	}

	/**
	 * @method generateReport : generates PDFReports from a static
	 *         report.rptdesign and saves the report to disk.
	 * @param servletRequest
	 * @param servletResponse
	 */
	public String generateReport(HttpServletRequest servletRequest,
			HttpServletResponse servletResponse, String reportType)
			throws EngineException, ReportDesignException {
		//name created for the new report.
		String reportName = ReportConstants.REPORT_ + System.currentTimeMillis()
				+ ReportConstants.REPORT_EXTENTION_PDF;

		logger.debug(ReportConstants.REPORT_NAME_TO_BE_GENERATED + reportName);
		
		servletContext = servletRequest.getSession().getServletContext();
		//design file being read.
		inputStream = servletContext
				.getResourceAsStream(ReportConstants.REPORT_DESIGN_SAMPLE_FILE_PATH
						+ reportType + ReportConstants.REPORT_DESIGN_EXTENSION);
		
		logger.debug(ReportConstants.READING_DESIGN_FILE + inputStream);
		
		if (inputStream == null) {
			throw new ReportDesignException(reportType);
		}

		reportEngine = reportEngineBean.getReportEngine();
		
		logger.debug(ReportConstants.REPORT_ENGINE_INSTANCE + reportEngine);
		
		runnable = reportEngine.openReportDesign(inputStream);
		//pdf rendering option be set.
		PDFRenderOption option = new PDFRenderOption();
		option.setOutputFormat(ReportConstants.REPORT_TYPE_PDF);
		option.setOutputFileName(this.servletContext
				.getRealPath(ReportConstants.PDF_REPORT_OUTPUT_PATH
						+ reportName));
		//task run and renders the report.
		IRunAndRenderTask runAndRenderTask = reportEngine
				.createRunAndRenderTask(runnable);
		runAndRenderTask.setRenderOption(option);
		runAndRenderTask.run();
		runAndRenderTask.close();
		
		logger.debug(ReportConstants.REPORT + reportName
				+ ReportConstants.SAVED_TO_DIRECTORY
				+ ReportConstants.PDF_REPORT_OUTPUT_PATH);
		return reportName;
	}
}
