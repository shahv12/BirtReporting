package com.reports.exception;
/**
 * ReportDesignException : exception thrown when the report design file is not 
 * read
 */
import com.reports.constants.ReportConstants;

public class ReportDesignException extends Exception {

	public ReportDesignException(String reportDesignName) {
		super(ReportConstants.READING_DESIGN_FILE_EXCEPTION + reportDesignName);
	}
}
