package com.reports.controller;

/**
 * XLSReportsController : intercepts different requests.
 * 
 */

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

import org.apache.log4j.Logger;
import org.eclipse.birt.report.engine.api.EngineException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.reports.constants.ReportConstants;
import com.reports.exception.ReportDesignException;
import com.reports.generator.XLSReportGenerator;

@Controller
public class XLSReportController {
	final static Logger logger = Logger.getLogger(XLSReportController.class);

	@Autowired
	public XLSReportGenerator xlsReportsGenerator;

	public XLSReportController() {
	}

	/**
	 * 
	 * @method : printHello : intercepts requests,containing the below path and
	 *         generates xls report.
	 * @param request
	 *            : empty
	 * @param servletRequest
	 * @param servletResponse
	 * @return
	 */
	@RequestMapping("/reports/xls/{reportType}")
	public ModelAndView generateReport(String request,
			@Context HttpServletRequest servletRequest,
			@Context HttpServletResponse servletResponse,
			@PathVariable("reportType") String reportType) {
		
		logger.debug(ReportConstants.REQUEST_RECEIVED_FOR_XLS_REPORTS);
		
		String reportName;
		try {
			reportName = xlsReportsGenerator.generateReport(servletRequest,
					servletResponse, reportType);
		}
		catch (EngineException engineException) {
			//error due to birt engine.
			logger.error(ReportConstants.REPORT_ENGINE_EXCEPTION,
					engineException);
			return new ModelAndView(ReportConstants.WELCOME_PAGE,
					ReportConstants.MESSAGE,
					ReportConstants.REPORT_ENGINE_EXCEPTION
							+ ReportConstants.REPORT_GENERATION_FAILED);
		}
		catch (ReportDesignException reportDesignException) {
			//error due to report design.
			logger.error(ReportConstants.DESIGN_FILE_EXCEPTION,
					reportDesignException);
			return new ModelAndView(ReportConstants.WELCOME_PAGE,
					ReportConstants.MESSAGE,
					ReportConstants.REPORT_DESIGN + reportType
							+ ReportConstants.CANNOT_BE_READ
							+ ReportConstants.REPORT_GENERATION_FAILED);
		}
		//success call. report name is displayed on welcome page.
		return new ModelAndView(ReportConstants.WELCOME_PAGE,
				ReportConstants.MESSAGE,
				ReportConstants.REPORT + reportName
						+ ReportConstants.GENERATED_SUCCESSFULLY);

	}
}
